package com.cdac.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cdac.model.Employee;

public class Main {
	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("Spring-Configuration.xml");
		
	  Employee employee = (Employee) context.getBean("employee");
	  System.out.println(employee); 
	  System.out.println(employee.getAddress());
	  
	  ((ClassPathXmlApplicationContext)context).close();
	}
}
