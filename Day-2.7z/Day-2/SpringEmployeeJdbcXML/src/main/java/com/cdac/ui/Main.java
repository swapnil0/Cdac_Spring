package com.cdac.ui;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cdac.model.Employee;
import com.cdac.service.EmployeeService;

public class Main {
	private static ApplicationContext context;
	public static void main(String[] args) {
		context = new ClassPathXmlApplicationContext("Spring-Configuration.xml");
		Employee employee = getContext().getBean("employee", Employee.class);
		employee.setEmployeeId(102);
		employee.setEmployeeName("Makarand Bhoir");
		employee.setEmployeeSalary(3500);
		
		EmployeeService service = getContext().getBean("service", EmployeeService.class);
		boolean result = service.addEmployee(employee);
		if(result) {
			System.out.println("Employee added.");
		}else {
			System.out.println("Employee not added.");
		}
		List<Employee> list = service.findAllEmployees();
		for(Employee emp : list) {
			System.out.println(emp);
		}
	}
	public static ApplicationContext getContext() {
		return context;
	}
}
