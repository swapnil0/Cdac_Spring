package com.cdac.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.cdac.model.Employee;
import com.cdac.utils.EmployeeQueries;
@Repository//("dao")
public class EmployeeDaoImpl implements EmployeeDao{
	@Autowired
	private JdbcTemplate template;
	
	public int createEmployee(Employee employee) {
		int result = getTemplate().update(EmployeeQueries.INSERT_EMPLOYEE_RECORD, 
			employee.getEmployeeId(), employee.getEmployeeName(), employee.getEmployeeSalary());
		return result;
	}
	public Employee readEmployeeById(int employeeId) {
		Employee employee = getTemplate().queryForObject(EmployeeQueries.GET_EMPLOYEE_BY_ID, new Object[] {employeeId}, 
				new EmployeeRowMapper());
		return employee;
	}
	public List<Employee> readAllEmployee() {
		List<Employee> employees = getTemplate().query(EmployeeQueries.GET_ALL_EMPLOYEE, new EmployeeRowMapper());
		return employees;
	}
	public int updateEmployee(Employee employee) {
		getTemplate().update(EmployeeQueries.UPDATE_EMPLOYEE_BY_ID, employee.getEmployeeName(), employee.getEmployeeSalary(), employee.getEmployeeId());
		return 0;
	}
	public int deleteEmployee(int employeeId) {
		int result = getTemplate().update(EmployeeQueries.DELETE_EMPLOYEE_BY_ID, employeeId);
		return result;
	}
	public JdbcTemplate getTemplate() {
		return template;
	}
	public void setTemplate(JdbcTemplate template) {
		this.template = template;
	}
}
