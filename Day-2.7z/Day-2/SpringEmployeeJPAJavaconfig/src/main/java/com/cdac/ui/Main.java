package com.cdac.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.cdac.config.AppConfig;
import com.cdac.model.Employee;
import com.cdac.service.EmployeeService;

public class Main {
	private static ApplicationContext context;
	public static void main(String[] args) {
		context = new AnnotationConfigApplicationContext(AppConfig.class);
		Employee employee = getContext().getBean("employee", Employee.class);
		employee.setEmployeeId(111);
		employee.setEmployeeName("Makarand Bhoir");
		employee.setEmployeeSalary(3500);
		employee.getAddress().setAddress_id(1);
		employee.getAddress().setCity("Mumbai");
		employee.getAddress().setPin("400001");
		employee.getAddress().setStreet("ABC Road");
		
		EmployeeService service = getContext().getBean("service", EmployeeService.class);
		boolean result = service.addEmployee(employee);
		if(result) {
			System.out.println("Employee added.");
		}else {
			System.out.println("Employee not added.");
		}
		Employee employee2 = service.findEmployeeById(employee.getEmployeeId());
		System.out.println(employee2);
	}
	public static ApplicationContext getContext() {
		return context;
	}
}
