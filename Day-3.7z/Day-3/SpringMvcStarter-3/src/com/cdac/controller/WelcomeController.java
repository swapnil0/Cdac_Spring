package com.cdac.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class WelcomeController {
	@RequestMapping(path="/", method=RequestMethod.GET)
	public String home() {
		return "index";
	}
	@RequestMapping(path="welcome.do", method=RequestMethod.GET)
	public String welcome() {
		System.out.println("Welcome controller is called....");
		return "welcome";
	}
	/*
	 * @RequestMapping(path="greeting.do", method=RequestMethod.POST) public String
	 * greet(HttpServletRequest request, Model model) { String firstName =
	 * request.getParameter("firstName"); String lastName =
	 * request.getParameter("lastName"); String fullName = firstName +" "+ lastName;
	 * //request.setAttribute("fullName", fullName); model.addAttribute("fullName",
	 * fullName); return "greeting"; }
	 */
	
	@RequestMapping(path="greeting.do", method=RequestMethod.POST)
	public String greet(@RequestParam("firstName") String fname, 
						@RequestParam("lastName") String lname, Model model) {
		String fullName = fname+" "+lname;
		model.addAttribute("fullName", fullName);
		return "greeting";
	}
}







