package com.cdac.utils;

public interface EmployeeQueries {
	public String INSERT_EMPLOYEE_RECORD = "insert into employee(employee_id, employee_name, employee_salary) values(:emp_id, :emp_name, :emp_sal)";
	public String GET_EMPLOYEE_BY_ID = "select * from employee where employee_id = ?";
	public String GET_ALL_EMPLOYEE = "select * from employee";
	public String DELETE_EMPLOYEE_BY_ID = "delete from employee where employee_id = ?";
	public String UPDATE_EMPLOYEE_BY_ID = "update employee set employee_name=?, employee_salary=? where employee_id=?";
	public String GET_EMPLOYEE_WITH_ADDRESS = "select employee_id, employee_name, employee_salary, "
			+ "city, street, pin from employee, address1 "
			+ "where employee.address_id = address1.address_id";
}
