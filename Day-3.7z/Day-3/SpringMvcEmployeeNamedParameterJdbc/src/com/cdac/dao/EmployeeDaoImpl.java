package com.cdac.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import com.cdac.model.Address;
import com.cdac.model.Employee;
import com.cdac.utils.EmployeeQueries;
@Repository//("dao")
public class EmployeeDaoImpl implements EmployeeDao{
	@Autowired
	private NamedParameterJdbcTemplate template;
	
	public int createEmployee(Employee employee) {
		Map<String, Object> parameters = new HashMap<>();
		parameters.put("emp_id", employee.getEmployeeId());
		parameters.put("emp_name", employee.getEmployeeName());
		parameters.put("emp_sal", employee.getEmployeeSalary());
		int reuslt = template.update(EmployeeQueries.INSERT_EMPLOYEE_RECORD, parameters);
		return reuslt;
	}
	public Employee readEmployeeById(int employeeId) {
		return null;
	}
	public List<Employee> readAllEmployee() {
		List<Employee> employees = getTemplate().query(EmployeeQueries.GET_ALL_EMPLOYEE, new EmployeeRowMapper());
		return employees;
	}
	public int updateEmployee(Employee employee) {
		return 0;
	}
	public int deleteEmployee(int employeeId) {
		return 1;
	}
	@Override
	public List<Employee> findEmployeesWithAddress() {
		List<Employee> list = getTemplate().query(EmployeeQueries.GET_EMPLOYEE_WITH_ADDRESS, 
				new RowMapper<Employee>() {
					@Override
					public Employee mapRow(ResultSet rs, int rowNum) throws SQLException {
						Employee employee = new Employee();
						employee.setAddress(new Address());
						
						employee.setEmployeeId(rs.getInt("employee_id"));
						employee.setEmployeeName(rs.getString("employee_name"));
						employee.setEmployeeSalary(rs.getDouble("employee_salary"));
						employee.getAddress().setCity(rs.getString("city"));
						employee.getAddress().setStreet(rs.getString("street"));
						employee.getAddress().setPin(rs.getString("pin"));
						return employee;
					}
		});
		return list;
	}
	public NamedParameterJdbcTemplate getTemplate() {
		return template;
	}
	public void setTemplate(NamedParameterJdbcTemplate template) {
		this.template = template;
	}
	
}
