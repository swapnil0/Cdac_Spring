package com.cdac.model;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component("employee2")
public class Employee {
	private int employeeId;
	private String employeeName;
	private double employeeSalary;
	
	//private Address address = new Address();
	@Autowired
	//@Qualifier("address1")
	private Address address1;
	
	public Employee() {
		System.out.println("Employee object created.");
	}
	public Employee(Address address1) {
		this.address1 = address1;
	}
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public double getEmployeeSalary() {
		return employeeSalary;
	}
	public void setEmployeeSalary(double employeeSalary) {
		this.employeeSalary = employeeSalary;
	}

	public Address getAddress1() {
		return address1;
	}

	public void setAddress(Address address1) {
		this.address1 = address1;
	}

	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", employeeName=" + employeeName + ", employeeSalary="
				+ employeeSalary + "]";
	}
	
}
