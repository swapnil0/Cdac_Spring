package com.cdac.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cdac.dao.EmployeeDao;
import com.cdac.model.Employee;
@Service("service")
public class EmployeeServiceImpl implements EmployeeService{
	@Autowired
	private EmployeeDao dao;
	public boolean addEmployee(Employee employee) {
		boolean result = getDao().createEmployee(employee);
		return result;
	}
	public Employee findEmployeeById(int employeeId) {
		Employee result = getDao().readEmployeeById(employeeId);
		return result;
	}
	public List<Employee> findAllEmployees() {
		List<Employee> result = getDao().readAllEmployee();
		return result;
	}
	public EmployeeDao getDao() {
		return dao;
	}
	public void setDao(EmployeeDao dao) {
		this.dao = dao;
	}
}
