package com.cdac.ui;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cdac.config.AppConfig;
import com.cdac.model.Employee;
import com.cdac.service.EmployeeService;

public class Main {
	public static void main(String[] args) {
		ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
		Employee employee = context.getBean("employee", Employee.class);
		employee.setEmployeeId(1000);
		employee.setEmployeeName("Makarand Bhoir");
		employee.setEmployeeSalary(5000);
		
		EmployeeService service = context.getBean("service", EmployeeService.class);
		boolean result = service.addEmployee(employee);
		if(result) {
			System.out.println("Employee added.");
		}else {
			System.out.println("Employee not added.");
		}
		List<Employee> list = service.findAllEmployees();
		for(Employee emp : list) {
			System.out.println(emp);
		}
	}
}
