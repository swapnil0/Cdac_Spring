package com.cdac.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.cdac.model.Employee;
@Repository("dao")
public class EmployeeDaoImpl implements EmployeeDao {
	private List<Employee> employees = new ArrayList<Employee>();
	public boolean createEmployee(Employee employee) {
		boolean result = employees.add(employee);
		return result;
	}
	public Employee readEmployeeById(int employeeId) {
		for(Employee emp : employees) {
			if(emp.getEmployeeId() == employeeId) {
				return emp;
			}
		}
		return null;
	}
	public List<Employee> readAllEmployee() {
		return employees;
	}
	public boolean updateEmployee(Employee employee) {
		return false;
	}
	public boolean deleteEmployee(int employeeId) {
		return false;
	}
}
