package com.cdac.dao;

import java.util.List;

import com.cdac.model.Employee;

public interface EmployeeDao {
	public boolean createEmployee(Employee employee);
	public Employee readEmployeeById(int employeeId);
	public List<Employee> readAllEmployee();
	public boolean updateEmployee(Employee employee);
	public boolean deleteEmployee(int employeeId);
}
