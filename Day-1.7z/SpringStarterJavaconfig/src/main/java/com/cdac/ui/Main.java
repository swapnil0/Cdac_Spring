package com.cdac.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.cdac.config.AppConfig;
import com.cdac.model.Employee;

public class Main {
	public static void main(String[] args) {
		ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
		
		Employee employee = (Employee)context.getBean("employee");
		System.out.println(employee);
		System.out.println(employee.getAddress());
	}
}
