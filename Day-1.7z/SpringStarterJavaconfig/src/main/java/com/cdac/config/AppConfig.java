package com.cdac.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

import com.cdac.model.Address;
import com.cdac.model.Employee;

@Configuration
public class AppConfig {
	@Bean(name="employee")
	@Scope(scopeName="prototype")
	public Employee getEmployee() {
		Employee employee = new Employee();
		employee.setAddress(getAddress());
		return employee;
	}
	@Bean(name="address")
	@Scope(scopeName="prototype")
	public Address getAddress() {
		Address address = new Address();
		return address;
	}
}
