package com.cdac.ui;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cdac.model.Employee;
import com.cdac.service.EmployeeService;

public class Main {
	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("Spring-Configuration.xml");
		Employee employee = context.getBean("employee", Employee.class);
		EmployeeService service = context.getBean("service", EmployeeService.class);
		boolean result = service.addEmployee(employee);
		if(result) {
			System.out.println("Employee added.");
		}else {
			System.out.println("Employee not added.");
		}
		List<Employee> list = service.findAllEmployees();
		for(Employee emp : list) {
			System.out.println(emp);
		}
	}
}
